{
  graphitePort: 2003
, graphiteHost: "graphite.host.com"
, port: 8125
}

