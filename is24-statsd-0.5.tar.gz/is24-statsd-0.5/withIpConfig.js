{
  graphitePort: 2003
, graphiteHost: "localhost"
, port: 8125
, debug: 1 
, measureByIP: 1
}

